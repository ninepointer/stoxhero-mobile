import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class portfolio_holding extends StatelessWidget {
  const portfolio_holding({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            buildSlidableCard(
              title: "Reliance Power",
              price: "₹23.95",
              percentage: "+0.70 (3.01%)",
              imagePath: 'assets/images/10Xlogo.jpg',
            ),
            // Add more cards as needed
          ],
        ),
      ),
    );
  }

  Widget buildSlidableCard({
    required String title,
    required String price,
    required String percentage,
    required String imagePath,
  }) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Slidable(
        startActionPane: ActionPane(
          motion: StretchMotion(),
          children: [
            SlidableAction(
              onPressed: (context) {
                // Handle phone action
              },
              icon: Icons.edit,
              backgroundColor: Colors.yellow,
              label: 'Edit',
            ),
            
          ],
        ),
        child: Container(
          height: 70,
          width: 400,
          padding: EdgeInsets.all(9),
          color: Colors.white,
          child: Row(
            children: [
              Padding(
                padding: const EdgeInsets.only(right: 12.0),
                child: Image.asset(
                  imagePath,
                  height: 20,
                  width: 20,
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      title,
                      style: TextStyle(
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    price,
                    style: TextStyle(
                      fontSize: 16,
                    ),
                  ),
                  SizedBox(height: 2),
                  Text(
                    percentage,
                    style: TextStyle(
                      color: Colors.green,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        endActionPane: ActionPane(
          motion: const StretchMotion(),
          children: [
            SlidableAction(
              onPressed: (context) {
                // Handle delete action
              },
              icon: Icons.delete,
              backgroundColor: Colors.red,
              label: 'DELETE',
            ),
          ],
        ),
      ),
    );
  }
}
