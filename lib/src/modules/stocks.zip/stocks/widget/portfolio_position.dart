import 'package:flutter/material.dart';

class portfolio_position extends StatelessWidget {
  const portfolio_position({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Text('Position Content'),
    );
  }
}