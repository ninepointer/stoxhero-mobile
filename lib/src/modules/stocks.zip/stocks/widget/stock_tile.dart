import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:stoxhero/src/modules/stocks/widget/watchlist.dart';

class StockTile extends StatefulWidget {
  final TodoItem item;
  const StockTile({super.key, required this.item});

  @override
  State<StockTile> createState() => _StockTileState();
}

class _StockTileState extends State<StockTile> {

  Key slidableKey = Key("");

  @override
  void initState() {
    slidableKey = Key('slidable_${widget.item.title}');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder:
          (BuildContext contextFromLayoutBuilder, BoxConstraints constraints) {
  bool isSlidableOpen = false;

        return GestureDetector(
          onTap: () {
            final slidable = Slidable.of(contextFromLayoutBuilder);

            if (isSlidableOpen) {
              slidable?.close();
              print('hii');

              setState(() {
                isSlidableOpen = !isSlidableOpen;
              });
            } else {
              slidable?.openStartActionPane(
                duration: const Duration(milliseconds: 500),
                curve: Curves.decelerate,
              );
              print('hello');
            }

            setState(() {
              isSlidableOpen = !isSlidableOpen;
            });

            print('Card tapped: ${widget.item.title}');
          },
          child: Column(
            children: [
              Slidable(
                key: slidableKey, // Use the key here

                startActionPane: ActionPane(
                  motion: StretchMotion(),
                  children: [
                    SlidableAction(
                      onPressed: (context) {
                        // Handle phone action
                      },
                      icon: Icons.shopping_cart,
                      backgroundColor: Colors.green,
                      label: 'BUY',
                    ),
                    SlidableAction(
                      onPressed: (context) {
                        // Handle delete action
                      },
                      icon: Icons.shopping_cart,
                      backgroundColor: Colors.red,
                      label: 'SELL',
                    ),
                  ],
                ),
                child: Container(
                  padding: EdgeInsets.all(9),
                  color: Colors.white,
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right: 12.0),
                        child: Image.asset(
                          widget.item.imagePath,
                          height: 20,
                          width: 20,
                        ),
                      ),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              widget.item.title,
                              style: TextStyle(
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            widget.item.price,
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                          SizedBox(height: 2),
                          Text(
                            widget.item.percentage,
                            style: TextStyle(
                              color: Colors.green,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                endActionPane: ActionPane(
                  motion: const StretchMotion(),
                  children: [
                    SlidableAction(
                      onPressed: (context) {
                        // Handle delete action
                      },
                      icon: Icons.delete,
                      backgroundColor: Colors.red,
                      label: 'DELETE',
                    ),
                  ],
                ),
              ),
              Divider(
                color: Colors.grey[200], // Adjust the color as needed
                thickness: 1.0,
              ),
            ],
          ),
        );
      },
    );
  }
}
