import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:stoxhero/src/modules/stocks/widget/stock_tile.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: ToDoListScreen(),
      ),
    );
  }
}

class ToDoListScreen extends StatefulWidget {
  @override
  _ToDoListScreenState createState() => _ToDoListScreenState();
}

class _ToDoListScreenState extends State<ToDoListScreen> {
  List<TodoItem> todoItems = [
    TodoItem(
      title: "Reliance Power",
      price: "₹23.95",
      percentage: "+0.70 (3.01%)",
      imagePath: 'assets/images/10Xlogo.jpg',
    ),
    // Add more items as needed
  ];
 bool isSlidableOpen = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background container with rounded edges
          Padding(
            padding: const EdgeInsets.only(top:25),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(25),
                  topRight: Radius.circular(25),
                ),
              ),
            ),
          ),

          // Container with search bar and button
          Container(
            margin: EdgeInsets.only(left: 10, right: 10),
            padding: EdgeInsets.symmetric(horizontal: 20),
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(25),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 2,
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.search),
                  color: Colors.grey,
                  onPressed: () {
                    // Handle the search action here
                    // For simplicity, I'm adding a hardcoded result
                    addNewItem(TodoItem(
                      title: "Search Result",
                      price: "₹50.00",
                      percentage: "+2.00 (4.00%)",
                      imagePath:  'assets/images/10Xlogo.jpg',
                    ));
                  },
                ),
                SizedBox(width: 10),
                Expanded(
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: "Search & add",
                      hintStyle: TextStyle(color: Colors.grey),
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Display existing todo items
          Expanded(
            child: Positioned(
              top: 65, // Adjust the top position as needed
              left: 0,
              right: 0,
             child: ListView.builder(
              shrinkWrap: true,
              itemCount: todoItems.length,
              itemBuilder: (context, index) {
               return StockTile(item: todoItems[index]);
             },
             ),
            ),
          ),
        ],
      ),
    );
  }
 // ...

Widget buildSlidableTodoCard(TodoItem item, int index) {
  final Key slidableKey = Key('slidable_$index'); // Unique key for each Slidable

  return LayoutBuilder(
    builder: (BuildContext contextFromLayoutBuilder, BoxConstraints constraints) {
      
      return GestureDetector(
        onTap: () {

          final slidable = Slidable.of(contextFromLayoutBuilder);

          if (isSlidableOpen) {
            slidable?.close();
            print('hii');
          } else {
            slidable?.openStartActionPane(
              duration: const Duration(milliseconds: 500),
              curve: Curves.decelerate,
            );
            print('hello');
          }

          setState(() {
            isSlidableOpen = !isSlidableOpen;
          });

      //      final slidable = Slidable.of(context);
      //     if (isSlidableOpen) {
      //       slidable?.close();
      //         print(slidable);
      //     } else {
      //       slidable?.openStartActionPane(
      //         duration: const Duration(milliseconds: 500),
      //         curve: Curves.decelerate,
      //       );
      //         print('open');
      //     }
      //     isSlidableOpen = !isSlidableOpen; // Toggle the state
      // // Handle the tap gesture here, you can add your logic
          print('Card tapped: ${item.title}');
         // Handle the tap gesture here
        //  final slidable = Slidable.of(context);
        //  slidable?.close(); // Close the Slidable, if open
        //  print('Card tapped!');
        },
        child: Column(
          children: [
            Slidable(
               key: slidableKey, // Use the key here
            
              startActionPane: ActionPane(
                motion: StretchMotion(),
                children: [
                  SlidableAction(
                    onPressed: (context) {
                      // Handle phone action
                    },
                    icon: Icons.shopping_cart,
                    backgroundColor: Colors.green,
                    label: 'BUY',
                  ),
                  SlidableAction(
                    onPressed: (context) {
                      // Handle delete action
                    },
                    icon: Icons.shopping_cart,
                    backgroundColor: Colors.red,
                    label: 'SELL',
                  ),
                ],
              ),
              child: Container(
                padding: EdgeInsets.all(9),
                color: Colors.white,
                child: Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(right: 12.0),
                      child: Image.asset(
                        item.imagePath,
                        height: 20,
                        width: 20,
                      ),
                    ),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            item.title,
                            style: TextStyle(
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          item.price,
                          style: TextStyle(
                            fontSize: 16,
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          item.percentage,
                          style: TextStyle(
                            color: Colors.green,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              endActionPane: ActionPane(
                motion: const StretchMotion(),
                children: [
                  SlidableAction(
                    onPressed: (context) {
                      // Handle delete action
                    },
                    icon: Icons.delete,
                    backgroundColor: Colors.red,
                    label: 'DELETE',
                  ),
                ],
              ),
            ),
            Divider(
              color: Colors.grey[200], // Adjust the color as needed
              thickness: 1.0,
            ),
          ],
        ),
      );
    },
  );
}



  void addNewItem(TodoItem newItem) {
    setState(() {
      todoItems.add(newItem);
    });
  }
}

class TodoItem {
  final String title;
  final String price;
  final String percentage;
  final String imagePath;

  TodoItem({
    required this.title,
    required this.price,
    required this.percentage,
    required this.imagePath,
  });
}
