import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';

class ToDoTile extends StatefulWidget {
  const ToDoTile({Key? key});

  @override
  State<ToDoTile> createState() => _ToDoTileState();
}

class _ToDoTileState extends State<ToDoTile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          // Background container with rounded edges
          Padding(
            padding: const EdgeInsets.only(top: 25),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(25),
                  topRight: Radius.circular(25),
                ),
              ),
            ),
          ),

          // Container with search bar and button
          Container(
            margin: EdgeInsets.only(left: 10, right: 10),
            padding: EdgeInsets.symmetric(horizontal: 20),
            height: 50,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.grey.withOpacity(0.2),
                  spreadRadius: 2,
                  blurRadius: 4,
                  offset: Offset(0, 2), // changes position of shadow
                ),
              ],
            ),
            child: Row(
              children: [
                IconButton(
                  icon: Icon(Icons.search),
                  color: Colors.grey,
                  onPressed: () {
                    // Handle the search action here
                  },
                ),
                SizedBox(width: 10),
                Expanded(
                  child: TextFormField(
                    decoration: InputDecoration(
                      hintText: "Search & add",
                      hintStyle: TextStyle(color: Colors.grey), // Set the color to grey
                      border: InputBorder.none,
                    ),
                  ),
                ),
              ],
            ),
          ),



          // Slidable widget
          Padding(
            padding: const EdgeInsets.only(top: 60),
            child: Container(
              padding: const EdgeInsets.all(8.0),
              child: Slidable(
                startActionPane: ActionPane(
                  motion: StretchMotion(),
                  children: [
                    SlidableAction(
                      onPressed: (context) {
                        // Handle phone action
                      },
                      icon: Icons.shopping_cart,
                      backgroundColor: Colors.green,
                      label: 'BUY',
                    ),
                    SlidableAction(
                      onPressed: (context) {
                        // Handle delete action
                      },
                      icon: Icons.shopping_cart,
                      backgroundColor: Colors.red,
                      label: 'SELL',
                    ),
                  ],
                ),
                child: LayoutBuilder(
                  builder: (contextFromLayoutBuilder, constraints) {
                    bool isSlidableOpen = false; // Add this variable
                    return GestureDetector(
                      child: Container(
                        height: 70,
                        width: 400,
                        padding: EdgeInsets.all(9),
                        color: Colors.white,
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 12.0),
                              child: Image.asset(
                                'assets/images/10Xlogo.jpg',
                                height: 20,
                                width: 20,
                              ),
                            ),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Text(
                                    "Reliance Power",
                                    style: TextStyle(
                                      fontSize: 16,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  "₹23.95",
                                  style: TextStyle(
                                    fontSize: 16,
                                  ),
                                ),
                                SizedBox(height: 2),
                                Text(
                                  "+0.70 (3.01%)",
                                  style: TextStyle(
                                    color: Colors.green,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      onTap: () {
                        final slidable = Slidable.of(contextFromLayoutBuilder);
                        if (isSlidableOpen) {
                          slidable?.close();
                        } else {
                          slidable?.openStartActionPane(
                            duration: const Duration(milliseconds: 500),
                            curve: Curves.decelerate,
                          );
                        }
                        isSlidableOpen = !isSlidableOpen; // Toggle the state
                      },
                    );
                  },
                ),
                endActionPane: ActionPane(
                  motion: const StretchMotion(),
                  children: [
                    SlidableAction(
                      onPressed: (context) {
                        // Handle delete action
                      },
                      icon: Icons.delete,
                      backgroundColor: Colors.red,
                      label: 'DELETE',
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
